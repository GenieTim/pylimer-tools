"""
DPD Simulations
===============

This example demonstrates how to set up and run a DPD simulation with slip-springs using pylimer-tools.

References: :cite:t:`langeloth_recovering_2013` and :cite:t:`schneider_simulation_2021`.

Assuming your ``pylimer_tools`` version was compiled with OpenMP,
to run this in parallel, you can use the typical OpenMP environment variables,
e.g., in the terminal before running your script: :code:`export OMP_NUM_THREADS=4` to use 4 threads.
"""

import os
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from pylimer_tools.io.read_lammps_output_file import read_data_file
from pylimer_tools_cpp import (
    AtomStyle,
    ComputedDoubleValues,
    ComputedIntValues,
    DPDSimulator,
    OutputConfiguration,
)


# Load a LAMMPS data file (replace with your file)
def _find_fixtures_dir() -> Path:
    for cur in (
        [Path(__file__).resolve().parent] if "__file__" in globals() else []
    ) + [Path.cwd()]:
        for p in [cur] + list(cur.parents):
            candidate = p / "tests" / "pylimer_tools" / "fixtures"
            if candidate.is_dir():
                return candidate
    return Path("tests/pylimer_tools/fixtures").resolve()


_fixtures_dir = _find_fixtures_dir()
filePath = str(_fixtures_dir / "structure/melt_83_a_100.structure.out")
universe = read_data_file(
    filePath, atom_style=[AtomStyle.HYBRID, AtomStyle.BOND, AtomStyle.EDPD]
)

# Create the DPD simulator
dpd_simulator = DPDSimulator(
    universe=universe,
    seed="12345",  # Set a random seed for reproducibility*
)
# %%
# Note that the random seed does not guarantee the same results across different runs,
# as the DPD algorithm is inherently stochastic and will produce different results
# if you use more than one processor.

# Randomly sample slip-springs
dpd_simulator.create_slip_springs(num=100)

# Configure what to output during the simulation on each step
step_output_config = OutputConfiguration()
step_output_config.int_values = [
    ComputedIntValues.STEP,  # Output the simulation step
]
step_output_config.double_values = [
    ComputedDoubleValues.TEMPERATURE,  # Output the temperature
    ComputedDoubleValues.PRESSURE,  # Output the pressure
    ComputedDoubleValues.STRESS_XX,  # Output the xx component of the stress tensor
    ComputedDoubleValues.STRESS_YY,  # Output the yy component of the stress tensor
    ComputedDoubleValues.STRESS_ZZ,  # Output the zz component of the stress tensor
]
step_output_config.output_every = 10  # Output every 10 steps
# temporary filename for output
step_output_config.filename = "dpd_simulation_output.txt"
dpd_simulator.config_step_output([step_output_config])

# Configure what to average during the simulation
avg_output_config = OutputConfiguration()
avg_output_config.int_values = [
    ComputedIntValues.STEP,  # Output the simulation step
]
avg_output_config.double_values = [
    ComputedDoubleValues.TEMPERATURE,  # Output the temperature
    ComputedDoubleValues.PRESSURE,  # Output the pressure
]
avg_output_config.output_every = 10
avg_output_config.use_every = 1
avg_output_config.filename = "dpd_simulation_avg_output.txt"
dpd_simulator.config_average_output([avg_output_config])

dpd_simulator.run_simulation(
    n_steps=1000,  # Number of simulation steps
    dt=0.01,  # Time step size
    with_MC=True,  # Enable Monte Carlo moves of slip-springs
)

print("DPD simulation completed.")

# %%
# read the output file and plot the diagonal stress components and
# thermodynamic observables
df = pd.read_csv("dpd_simulation_output.txt", sep="\\s+")

fig, ax = plt.subplots(figsize=(7, 4.5))
for col, label in [
    ("Stress[0,0]", r"$\sigma_{xx}$"),
    ("Stress[1,1]", r"$\sigma_{yy}$"),
    ("Stress[2,2]", r"$\sigma_{zz}$"),
]:
    ax.plot(df["Step"], df[col], label=label)
ax.set_xlabel("Step")
ax.set_ylabel("Stress [DPD units]")
ax.set_title("Diagonal Stress Tensor Components")
ax.grid(True, linestyle="--", alpha=0.5)
ax.legend()
plt.tight_layout()
plt.show()

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.plot(df["Step"], df["Temperature"], label="Temperature", color="#1f77b4")
ax.plot(df["Step"], df["Pressure"], label="Pressure", color="#d95f02")
ax.set_xlabel("Step")
ax.set_ylabel("Value [DPD units]")
ax.set_title("Temperature and Pressure")
ax.grid(True, linestyle="--", alpha=0.5)
ax.legend()
plt.tight_layout()
plt.show()
